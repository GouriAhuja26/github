import React from 'react';
import { Button, StyleSheet, Text, View ,TextInput, ImageBackground} from 'react-native';



export default class About extends React.Component{

        render(){
            const { navigate, state } = this.props.navigation;
            return(
            <ImageBackground source={require('./image/blue1.jpg')} style={{width:null,height:900,flex:1,justifyContent:'center'}}> 
                <View>
                <Text style={{fontSize:30,justifyContent:'center',textAlign:'center'}}>Welcome</Text>
                <Text style={{fontSize:20,justifyContent:'center',textAlign:'center'}}>To About Page</Text>
           

                </View>


                </ImageBackground>
            )
        }


}