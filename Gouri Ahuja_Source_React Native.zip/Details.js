import React from 'react';
import {SafeAreaView, StyleSheet, View, Text, ImageBackground} from 'react-native';

export default class Details extends React.Component{

        render(){
            //const { navigate, state } = this.props.navigation;
            const { navigation } = this.props;  
            const name = navigation.getParam('name','Gouri')
            const email = navigation.getParam('email', 'Not_Defined') 
            return(
               <ImageBackground source={require('./images/blue1.jpg')} style={{width:null,height:null,flex:1,justifyContent:'center'}}>
               <View>
                  
                <Text style={{fontSize:30,justifyContent:'center',textAlign:'center'}}>Registration Page Details </Text>
                <Text>{"\n"}</Text>
                <Text style={{fontSize:20,justifyContent:'center',textAlign:'center'}}>Name : {JSON.stringify(name)}</Text>  
                <Text>{"\n"}</Text>
                <Text style={{fontSize:20,justifyContent:'center',textAlign:'center'}}>Email : {JSON.stringify(email)}</Text> 
               
                </View>
                </ImageBackground>
               
                
            )
        }


}