import { StatusBar } from 'expo-status-bar';
import { Formik } from 'formik';
import React from 'react';
import { Button, StyleSheet, Text, View ,TextInput, ImageBackground,TouchableHighlight} from 'react-native';
import {withFormik} from 'formik';


 class Login extends React.Component {
    state={
        email:"",
        password:""
      }

    static navigationOptions = {
        title: 'Login',
    };

    render() {
            
        const { navigate } = this.props.navigation;

        return (
          
             
            <View style={styles.container}>
                <ImageBackground source={require('./image/blue1.jpg')} style={{width:360,height:900,flex:1,justifyContent:'center'}}> 
            <Text style={{fontSize:34,color:'black',textAlign:'center'}}>Login </Text>
      
            <Text>{"\n"}</Text>
      <TextInput placeholder={"Enter the username"}
        

      //value={email}
      onChangeText={email=>this.props.setFieldValue('email',email)}
      style={{height:42,width:"80%",borderBottomWidth:1,paddingRight:1}}/>

       <Text style={styles.validatetext}>{this.props.errors.email}</Text> 
       <Text>{"\n"}</Text>

      <TextInput placeholder={"Enter the Password"}
      
      secureTextEntry={true}
      onChangeText={password=>this.props.setFieldValue('password',password)}
      style={{height:42,width:"80%",borderBottomWidth:1}}/>

      <Text style={styles.validatetext}>{this.props.errors.password}</Text> 
      
      <TouchableHighlight style={{padding:10,margin:20,backgroundColor:'(rgba(230,75,82,1))',borderRadius:4,textAlign:'center'}}   onPress={()=>{this.props.handleSubmit()}}>
                <Text>Login</Text>
              </TouchableHighlight>

        {/* <Button
                    
                    title="Login"
                    onPress={()=>{this.props.handleSubmit()}}
                    
                /> */}
 
 <TouchableHighlight style={{padding:10,margin:20,backgroundColor:'(rgba(230,75,82,1))',borderRadius:4,textAlign:'center'}}    onPress={() => navigate(
                        'Registration'
                    )}>
                <Text>Registration</Text>
              </TouchableHighlight>
                {/* <br/>
                <Button
                    
                    title="Registration"
                    onPress={() => navigate(
                        'Registration'
                    )}
                />
                 */}
     
                
        </ImageBackground>  

            </View>
            
         
        );

    }

}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    validatetext:{
      color:'red'
    },
    button:{

    }
  });
  
  
  export default withFormik({
  mapPropsToValues: () => ({email:"",password:""}),
  validate:(values,props) => {
      const errors={};
      if(!values.email){
        errors.email='Email Required';
        
      }
  
      if(!values.password){
        errors.password='Password Required';
      }else if(values.password.length<8) {
            errors.password='Minimum length of password is 8 character';
      }
      return errors;
  },
  handleSubmit: (values, {props})=>{
    if(values.email=="Gouri" && values.password=="Gouri123")
    
    {
               props.navigation.navigate('About');
    }else {
        errors.email("Inavlid Username");
    }
    console.log(values)
  },
  })(Login);